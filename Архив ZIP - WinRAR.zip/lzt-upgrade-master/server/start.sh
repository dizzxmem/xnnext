#!/bin/bash
screen -S "lztupgrade" python3 main.py